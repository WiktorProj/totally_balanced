SMODS.Sound{
    key="meow",
    path="meow.ogg",
    pitch=0.7,
    volume=0.6
}

SMODS.Sound{
    key="tawww",
    path="tawww.ogg",
    pitch=0.7,
    volume=0.6
}